Box2DFlash v2.1 alpha
Release 28 Mar 2010 by Boris The Brave

See source files for license.

visit 
* http://box2dflash.boristhebrave.com
* http://sourceforge.net/projects/box2dflash/
for updates/details